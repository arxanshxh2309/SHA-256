"""End-to-end tour: hash, HMAC, Merkle tree, length-extension forge.

Run with:
    PYTHONPATH=. python examples/tour.py
"""
from __future__ import annotations

from hashforge import (
    MerkleTree,
    forge_extension,
    hmac_sha256,
    sha256,
    verify_proof,
)


def banner(text: str) -> None:
    print(f"\n\033[1;36m── {text} ──\033[0m")


def main() -> None:
    banner("1. SHA-256 of 'abc' (FIPS 180-4 Appendix B)")
    print(f"  {sha256(b'abc').hex()}")
    print("  expected:")
    print("  ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")

    banner("2. HMAC-SHA256")
    tag = hmac_sha256(b"key", b"The quick brown fox jumps over the lazy dog")
    print(f"  HMAC(key, fox) = {tag.hex()}")

    banner("3. Merkle tree of 8 transactions")
    txs = [f"tx-{i}".encode() for i in range(8)]
    tree = MerkleTree.build(txs)
    print(f"  root = {tree.root.hex()}")
    proof = tree.proof(5)
    print(f"  proof for tx-5: {len(proof)} sibling hashes")
    for s in proof:
        side = "right" if s.is_right else "left "
        print(f"    {side} : {s.sibling.hex()[:32]}...")
    ok = verify_proof(b"tx-5", 5, proof, tree.root)
    print(f"  verify_proof(tx-5) → {ok}")

    banner("4. Length-extension attack against H(secret ‖ msg)")
    secret = b"super-secret-do-not-tell"        # 24 bytes
    original_msg = b"amount=10&to=alice"
    public_tag = sha256(secret + original_msg)  # what a naive server publishes
    print(f"  original tag : {public_tag.hex()}")
    print(f"  original msg : {original_msg!r}")

    forge = forge_extension(
        original_tag=public_tag,
        original_msg=original_msg,
        secret_length=len(secret),
        extension=b"&amount=999999&to=mallory",
    )
    server_tag = sha256(secret + forge.forged_message)
    print(f"  forged tag   : {forge.forged_tag.hex()}")
    print(f"  server tag   : {server_tag.hex()}")
    print(f"  ⚠  match     : {forge.forged_tag == server_tag}")

    banner("5. Same attack against HMAC fails (this is why HMAC exists)")
    hmac_tag = hmac_sha256(secret, original_msg)
    f2 = forge_extension(hmac_tag, original_msg, len(secret), b"&amount=999999")
    server_check = hmac_sha256(secret, f2.forged_message)
    print(f"  HMAC accepts forgery: {f2.forged_tag == server_check}")
    print("  ✓ length extension does not apply to HMAC")


if __name__ == "__main__":
    main()
