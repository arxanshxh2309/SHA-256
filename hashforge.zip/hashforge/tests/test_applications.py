"""Tests for HMAC, Merkle trees, and the length-extension attack."""
import hashlib
import hmac as stdlib_hmac
import secrets

import pytest

from hashforge.hmac import constant_time_equals, hmac_sha256, verify
from hashforge.length_extension import forge_extension
from hashforge.merkle import MerkleTree, hash_leaf, hash_node, verify_proof
from hashforge.sha256 import sha256


# ---------------------------------------------------------------------------
# HMAC
# ---------------------------------------------------------------------------
class TestHmac:
    """Match Python stdlib (which is RFC 2104) on every input."""

    @pytest.mark.parametrize("key,msg", [
        (b"", b""),
        (b"key", b"The quick brown fox jumps over the lazy dog"),
        (b"k" * 64, b"key exactly block size"),
        (b"k" * 100, b"key longer than block size"),
        (b"\x0b" * 20, b"Hi There"),  # RFC 4231 test 1 setup
    ])
    def test_against_stdlib(self, key, msg):
        assert hmac_sha256(key, msg) == stdlib_hmac.new(key, msg, hashlib.sha256).digest()

    def test_random_fuzz(self):
        for _ in range(100):
            k = secrets.token_bytes(secrets.randbelow(150))
            m = secrets.token_bytes(secrets.randbelow(2000))
            assert hmac_sha256(k, m) == stdlib_hmac.new(k, m, hashlib.sha256).digest()

    def test_verify_accepts_correct_tag(self):
        tag = hmac_sha256(b"key", b"msg")
        assert verify(b"key", b"msg", tag)

    def test_verify_rejects_modified_tag(self):
        tag = hmac_sha256(b"key", b"msg")
        bad = bytes([tag[0] ^ 1]) + tag[1:]
        assert not verify(b"key", b"msg", bad)

    def test_verify_rejects_modified_message(self):
        tag = hmac_sha256(b"key", b"msg")
        assert not verify(b"key", b"msg2", tag)


class TestConstantTimeCompare:
    def test_equal_returns_true(self):
        assert constant_time_equals(b"abc123", b"abc123")

    def test_unequal_returns_false(self):
        assert not constant_time_equals(b"abc123", b"abc124")

    def test_length_mismatch_returns_false(self):
        assert not constant_time_equals(b"abc", b"abcd")


# ---------------------------------------------------------------------------
# Merkle tree
# ---------------------------------------------------------------------------
class TestMerkleTree:
    @pytest.mark.parametrize("n", [1, 2, 3, 4, 5, 7, 8, 16, 17, 33])
    def test_every_leaf_proves(self, n):
        items = [f"item-{i}".encode() for i in range(n)]
        tree = MerkleTree.build(items)
        for i, item in enumerate(items):
            proof = tree.proof(i)
            assert verify_proof(item, i, proof, tree.root)

    def test_proof_length_is_log_n(self):
        # Proof length matches tree depth (level count - 1)
        items = [bytes([i]) for i in range(8)]
        tree = MerkleTree.build(items)
        # 8 leaves → 4 → 2 → 1, that's 4 levels, 3 proof steps
        assert len(tree.proof(0)) == 3

    def test_forged_leaf_rejected(self):
        items = [f"item-{i}".encode() for i in range(7)]
        tree = MerkleTree.build(items)
        proof = tree.proof(2)
        assert not verify_proof(b"forged", 2, proof, tree.root)

    def test_wrong_root_rejected(self):
        items = [b"a", b"b", b"c", b"d"]
        tree = MerkleTree.build(items)
        wrong_root = bytes([tree.root[0] ^ 1]) + tree.root[1:]
        assert not verify_proof(items[0], 0, tree.proof(0), wrong_root)

    def test_wrong_index_rejected(self):
        items = [f"item-{i}".encode() for i in range(8)]
        tree = MerkleTree.build(items)
        proof_for_3 = tree.proof(3)
        # Trying to use leaf 3's proof with leaf 4's data + index 4 fails
        assert not verify_proof(items[4], 4, proof_for_3, tree.root)

    def test_empty_tree_rejected(self):
        with pytest.raises(ValueError):
            MerkleTree.build([])

    def test_domain_separation(self):
        """Leaves and internal nodes use disjoint hash domains, so an
        internal node can't be passed off as a leaf."""
        leaf = hash_leaf(b"x")
        node = hash_node(b"x" * 32, b"y" * 32)
        # Different prefixes mean different hashes even for crafted inputs
        assert leaf != node


# ---------------------------------------------------------------------------
# Length-extension attack
# ---------------------------------------------------------------------------
class TestLengthExtension:
    """The attack must successfully forge a tag against the naive
    H(secret || message) construction, and must FAIL against HMAC."""

    @pytest.mark.parametrize("secret_len", [1, 8, 16, 32, 50, 100])
    def test_attack_succeeds_against_naive_mac(self, secret_len):
        secret = secrets.token_bytes(secret_len)
        original_msg = b"amount=10&to=alice"
        original_tag = sha256(secret + original_msg)

        forge = forge_extension(
            original_tag=original_tag,
            original_msg=original_msg,
            secret_length=secret_len,
            extension=b"&amount=999&to=mallory",
        )
        # The server, recomputing from its (still-secret) secret, agrees.
        assert sha256(secret + forge.forged_message) == forge.forged_tag

    def test_extension_is_actually_appended(self):
        secret = b"swordfish"
        msg = b"hello"
        tag = sha256(secret + msg)
        ext = b"&extra"
        forge = forge_extension(tag, msg, len(secret), ext)
        assert forge.forged_message.startswith(msg)
        assert forge.forged_message.endswith(ext)

    def test_attack_fails_against_hmac(self):
        secret = secrets.token_bytes(16)
        msg = b"amount=10"
        tag = hmac_sha256(secret, msg)
        forge = forge_extension(tag, msg, len(secret), b"&extra")
        # The server's HMAC will NOT match — that's the whole point
        assert hmac_sha256(secret, forge.forged_message) != forge.forged_tag

    def test_wrong_secret_length_fails(self):
        secret = b"twelvebytes!"   # 12 bytes
        msg = b"x"
        tag = sha256(secret + msg)
        # Attacker guesses the wrong length
        forge = forge_extension(tag, msg, secret_length=11, extension=b"y")
        assert sha256(secret + forge.forged_message) != forge.forged_tag
