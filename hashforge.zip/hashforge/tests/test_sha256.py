"""SHA-256 correctness tests."""
import hashlib
import secrets

import pytest

from hashforge.sha256 import (
    Sha256,
    Trace,
    pad_message,
    sha256,
)


# NIST FIPS 180-4 + CAVP test vectors that any SHA-256 implementation
# is expected to pass. The 1-million-'a' vector is the canonical
# correctness check for streaming.
NIST_VECTORS = [
    (b"", "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"),
    (b"abc",
     "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"),
    (b"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",
     "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"),
    (b"abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmno"
     b"ijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnopqrstu",
     "cf5b16a778af8380036ce59e7b0492370b249b11e8f07a51afac45037afee9d1"),
    (b"a" * 1_000_000,
     "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0"),
]


class TestNistVectors:
    @pytest.mark.parametrize("msg,expected", NIST_VECTORS)
    def test_oneshot(self, msg, expected):
        assert sha256(msg).hex() == expected

    @pytest.mark.parametrize("msg,expected", NIST_VECTORS)
    def test_streaming_byte_by_byte(self, msg, expected):
        h = Sha256()
        for i in range(0, len(msg), 1):
            h.update(msg[i : i + 1])
        assert h.hexdigest() == expected


class TestStreamingEquivalence:
    """Streaming with arbitrary chunk sizes must produce the same digest."""

    @pytest.mark.parametrize("chunk", [1, 7, 13, 63, 64, 65, 127, 128, 1000])
    def test_chunk_sizes(self, chunk):
        data = secrets.token_bytes(50_000)
        h = Sha256()
        for i in range(0, len(data), chunk):
            h.update(data[i : i + chunk])
        assert h.digest() == hashlib.sha256(data).digest()

    def test_empty_then_data(self):
        h = Sha256()
        h.update(b"")
        h.update(b"hello")
        h.update(b"")
        assert h.hexdigest() == hashlib.sha256(b"hello").hexdigest()


class TestAgainstHashlib:
    """Random fuzz against the C-backed reference implementation."""

    def test_random_inputs(self):
        for _ in range(500):
            n = secrets.randbelow(2048)
            data = secrets.token_bytes(n)
            assert sha256(data) == hashlib.sha256(data).digest()


class TestPadding:
    def test_empty_message(self):
        # Empty input pads to one full block: 0x80 + 55 zeros + 8-byte length=0
        padded = pad_message(b"")
        assert len(padded) == 64
        assert padded[0] == 0x80
        assert padded[-8:] == b"\x00" * 8

    def test_55_byte_message_fits_one_block(self):
        msg = b"x" * 55
        padded = pad_message(msg)
        assert len(padded) == 64
        # Length field is in BITS, big-endian
        assert int.from_bytes(padded[-8:], "big") == 55 * 8

    def test_56_byte_message_spills_to_second_block(self):
        msg = b"x" * 56
        padded = pad_message(msg)
        assert len(padded) == 128

    def test_padded_length_always_multiple_of_64(self):
        for n in range(0, 200):
            assert len(pad_message(b"\x00" * n)) % 64 == 0


class TestTraceMode:
    """Trace recorder captures the full computation for educational use."""

    def test_abc_block_count_and_round_count(self):
        t = Trace()
        sha256(b"abc", trace=t)
        assert len(t.blocks) == 1
        assert len(t.blocks[0].rounds) == 64
        assert len(t.blocks[0].message_schedule) == 64

    def test_trace_first_schedule_word_for_abc(self):
        # FIPS 180-4 Appendix B: W[0] for "abc" is 0x61626380
        # ('a','b','c', 0x80 padding byte, then zero-padded to 4 bytes).
        t = Trace()
        sha256(b"abc", trace=t)
        assert t.blocks[0].message_schedule[0] == 0x61626380

    def test_trace_initial_state_is_H0(self):
        from hashforge.sha256 import H0
        t = Trace()
        sha256(b"abc", trace=t)
        assert t.blocks[0].H_in == H0

    def test_long_input_produces_multiple_blocks(self):
        t = Trace()
        sha256(b"x" * 200, trace=t)
        # 200 + 1 (0x80) + 8 (length) = 209 → padded to 256 → 4 blocks
        assert len(t.blocks) == 4


class TestSha256ApiCompatibility:
    """Sha256 should be a near-drop-in for hashlib.sha256."""

    def test_attributes(self):
        assert Sha256.block_size == 64
        assert Sha256.digest_size == 32
        assert Sha256.name == "sha256"

    def test_idempotent_digest(self):
        h = Sha256(b"hello")
        d1 = h.digest()
        d2 = h.digest()
        assert d1 == d2

    def test_update_after_digest(self):
        h = Sha256(b"hello")
        d1 = h.digest()
        h.update(b" world")
        d2 = h.digest()
        assert d1 != d2
        assert d2 == hashlib.sha256(b"hello world").digest()
