"""Hashforge CLI.

    hashforge hash FILE                          # SHA-256 of a file
    hashforge hmac --key KEY FILE                # HMAC-SHA256
    hashforge merkle build FILE [FILE ...]       # build a Merkle tree
    hashforge merkle prove TREE INDEX            # generate inclusion proof
    hashforge attack length-extension ...        # forge a tag
    hashforge trace MESSAGE                      # show every round
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import click

from . import (
    MerkleTree,
    ProofStep,
    Trace,
    forge_extension,
    hmac_sha256,
    sha256,
    verify,
    verify_proof,
)


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option()
def cli() -> None:
    """🔨 Hashforge — SHA-256 from scratch, with friends."""


# ---------------------------------------------------------------------------
#  hash
# ---------------------------------------------------------------------------
@cli.command("hash")
@click.argument("file", type=click.Path(exists=True, dir_okay=False, path_type=Path))
def hash_cmd(file: Path) -> None:
    """SHA-256 of FILE."""
    click.echo(f"{sha256(file.read_bytes()).hex()}  {file}")


# ---------------------------------------------------------------------------
#  hmac
# ---------------------------------------------------------------------------
@cli.command("hmac")
@click.option("--key", required=True, help="HMAC key (utf-8 string)")
@click.option("--key-hex", help="HMAC key as hex (overrides --key)")
@click.argument("file", type=click.Path(exists=True, dir_okay=False, path_type=Path))
def hmac_cmd(key: str, key_hex: str | None, file: Path) -> None:
    """HMAC-SHA256(KEY, FILE)."""
    k = bytes.fromhex(key_hex) if key_hex else key.encode("utf-8")
    click.echo(f"{hmac_sha256(k, file.read_bytes()).hex()}  {file}")


# ---------------------------------------------------------------------------
#  merkle
# ---------------------------------------------------------------------------
@cli.group("merkle")
def merkle_grp() -> None:
    """Merkle tree commands."""


@merkle_grp.command("build")
@click.argument("files", nargs=-1, type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--proofs/--no-proofs", default=False, help="Print every leaf's proof")
def merkle_build(files: tuple[Path, ...], proofs: bool) -> None:
    """Build a Merkle tree over the contents of FILES."""
    if not files:
        raise click.UsageError("provide at least one file")
    items = [f.read_bytes() for f in files]
    tree = MerkleTree.build(items)
    click.echo(f"Leaves: {len(items)}")
    click.echo(f"Levels: {len(tree.levels)}")
    click.echo(f"Root  : {tree.root.hex()}")
    if proofs:
        click.echo()
        for i, f in enumerate(files):
            steps = tree.proof(i)
            click.echo(f"Proof for leaf {i} ({f}):")
            for s in steps:
                side = "right" if s.is_right else "left"
                click.echo(f"  {side:>5}: {s.sibling.hex()}")


# ---------------------------------------------------------------------------
#  attack
# ---------------------------------------------------------------------------
@cli.group("attack")
def attack_grp() -> None:
    """Cryptographic attack demonstrations."""


@attack_grp.command("length-extension")
@click.option("--tag-hex", required=True, help="Original SHA-256 tag, hex")
@click.option("--message", required=True, help="Original message (utf-8)")
@click.option("--secret-length", type=int, required=True, help="Length of the unknown secret in bytes")
@click.option("--extension", required=True, help="Bytes you want to append (utf-8)")
def le_cmd(tag_hex: str, message: str, secret_length: int, extension: str) -> None:
    """Forge SHA256(secret ‖ message ‖ glue ‖ extension) without knowing the secret."""
    forge = forge_extension(
        original_tag=bytes.fromhex(tag_hex),
        original_msg=message.encode("utf-8"),
        secret_length=secret_length,
        extension=extension.encode("utf-8"),
    )
    click.secho("⚠  Forged payload", fg="yellow", bold=True)
    click.echo(f"  forged_tag : {forge.forged_tag.hex()}")
    click.echo(f"  glue (hex) : {forge.glue.hex()}")
    click.echo(f"  message    : {forge.forged_message!r}")
    click.echo()
    click.echo("Hand both the message and the forged tag to the server. If it")
    click.echo("computes SHA256(secret ‖ message), it will accept this as valid.")


# ---------------------------------------------------------------------------
#  trace
# ---------------------------------------------------------------------------
@cli.command("trace")
@click.argument("message", required=True)
@click.option("--rounds/--no-rounds", default=True, help="Print all 64 rounds per block")
@click.option("--schedule/--no-schedule", default=True, help="Print the message schedule W[0..63]")
def trace_cmd(message: str, rounds: bool, schedule: bool) -> None:
    """Hash MESSAGE and print every round of the SHA-256 compression."""
    t = Trace()
    digest = sha256(message.encode("utf-8"), trace=t)

    click.echo(f"Message    : {message!r}")
    click.echo(f"Padded len : {len(t.padded_input)} bytes ({len(t.blocks)} blocks)")
    click.echo(f"Digest     : {digest.hex()}")

    for blk in t.blocks:
        click.echo()
        click.secho(f"── Block {blk.block_index} ──", fg="cyan")
        click.echo(f"  H_in : {' '.join(f'{x:08x}' for x in blk.H_in)}")
        if schedule:
            click.echo("  W[0..63]:")
            for row in range(8):
                words = blk.message_schedule[row * 8 : (row + 1) * 8]
                click.echo("    " + " ".join(f"{w:08x}" for w in words))
        if rounds:
            click.echo("  rounds (a b c d e f g h):")
            for r in blk.rounds:
                click.echo(f"    t={r.t:>2}  {r.a:08x} {r.b:08x} {r.c:08x} {r.d:08x}  "
                           f"{r.e:08x} {r.f:08x} {r.g:08x} {r.h:08x}")
        click.echo(f"  H_out: {' '.join(f'{x:08x}' for x in blk.H_out)}")


if __name__ == "__main__":  # pragma: no cover
    cli()
