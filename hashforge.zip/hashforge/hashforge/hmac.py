"""
HMAC-SHA256 — RFC 2104.

HMAC is the answer to the question "how do I authenticate a message
with a shared key?" The naive approach — ``H(key || message)`` — is
broken in general (see :mod:`hashforge.length_extension`). HMAC is the
construction that *isn't*.

    HMAC(K, m) = H((K' ⊕ opad) ‖ H((K' ⊕ ipad) ‖ m))

where K' is the key, padded to one SHA-256 block (64 bytes) — either by
right-zero-padding short keys or by hashing keys longer than the block
size.
"""
from __future__ import annotations

from .sha256 import BLOCK_SIZE, sha256

IPAD = 0x36
OPAD = 0x5C


def hmac_sha256(key: bytes, message: bytes) -> bytes:
    """Compute HMAC-SHA256(``key``, ``message``).

    >>> hmac_sha256(b'key', b'The quick brown fox jumps over the lazy dog').hex()
    'f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8'
    """
    # Step 1: normalize the key to exactly BLOCK_SIZE bytes.
    if len(key) > BLOCK_SIZE:
        key = sha256(key)
    if len(key) < BLOCK_SIZE:
        key = key + b"\x00" * (BLOCK_SIZE - len(key))

    inner_pad = bytes(b ^ IPAD for b in key)
    outer_pad = bytes(b ^ OPAD for b in key)

    inner_hash = sha256(inner_pad + message)
    return sha256(outer_pad + inner_hash)


def constant_time_equals(a: bytes, b: bytes) -> bool:
    """Compare two byte strings in time independent of where they differ.

    Use this whenever you check a MAC. Comparing tags with ``==`` leaks
    timing information that real-world attackers have used to forge MACs.
    """
    if len(a) != len(b):
        return False
    diff = 0
    for x, y in zip(a, b):
        diff |= x ^ y
    return diff == 0


def verify(key: bytes, message: bytes, tag: bytes) -> bool:
    """Constant-time HMAC verification."""
    return constant_time_equals(hmac_sha256(key, message), tag)


__all__ = ["hmac_sha256", "verify", "constant_time_equals"]
