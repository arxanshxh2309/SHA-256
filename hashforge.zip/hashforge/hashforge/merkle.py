"""
Merkle trees with inclusion proofs (RFC 6962-style).

A Merkle tree is a binary tree of hashes. Each leaf is the hash of a
data item; each internal node is the hash of its two children
concatenated. The single hash at the root is a 32-byte commitment to
the entire data set. With an *inclusion proof* (the sibling hashes on
the path from a leaf to the root, O(log n) of them), anyone can verify
that a specific leaf is in a tree with that root — without seeing the
other leaves.

This is the construction Bitcoin uses to commit to transactions, Git
uses for trees and commits, IPFS uses for content addressing, and
Certificate Transparency uses to make TLS misissuance auditable.

Domain separation
-----------------
Pure ``H(left ‖ right)`` is vulnerable to *second-preimage* attacks: an
attacker can present an internal node as if it were a leaf. The fix
(RFC 6962) is to prefix leaves with ``0x00`` and internal nodes with
``0x01`` before hashing, making the two hash domains disjoint.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence

from .sha256 import sha256

LEAF_PREFIX = b"\x00"
NODE_PREFIX = b"\x01"


def hash_leaf(data: bytes) -> bytes:
    return sha256(LEAF_PREFIX + data)


def hash_node(left: bytes, right: bytes) -> bytes:
    return sha256(NODE_PREFIX + left + right)


@dataclass(frozen=True)
class ProofStep:
    """One step of an inclusion proof: a sibling hash and which side it sits on."""
    sibling: bytes
    is_right: bool   # True if the sibling is the right child at this level


@dataclass
class MerkleTree:
    """A Merkle tree built from an ordered list of byte strings.

    Odd-leaf-count handling: the *last* leaf at any level is duplicated
    if it has no sibling. This matches Bitcoin's behavior. (RFC 6962
    instead uses a ragged tree; the choice is arbitrary but must be
    fixed for proofs to verify consistently.)
    """
    leaves: List[bytes]
    levels: List[List[bytes]]   # levels[0] = leaf hashes; levels[-1] = [root]

    @classmethod
    def build(cls, items: Sequence[bytes]) -> "MerkleTree":
        if not items:
            raise ValueError("Merkle tree requires at least one leaf")

        leaves = [hash_leaf(x) for x in items]
        levels = [leaves]
        while len(levels[-1]) > 1:
            cur = levels[-1]
            nxt: List[bytes] = []
            for i in range(0, len(cur), 2):
                left = cur[i]
                right = cur[i + 1] if i + 1 < len(cur) else cur[i]  # duplicate odd
                nxt.append(hash_node(left, right))
            levels.append(nxt)
        return cls(leaves=list(items), levels=levels)

    @property
    def root(self) -> bytes:
        return self.levels[-1][0]

    def proof(self, index: int) -> List[ProofStep]:
        """Inclusion proof for the leaf at position ``index``.

        Returns the list of (sibling_hash, side) pairs needed to walk from
        the leaf up to the root. Length is ⌈log₂ n⌉.
        """
        if not 0 <= index < len(self.leaves):
            raise IndexError(f"leaf index {index} out of range")

        steps: List[ProofStep] = []
        idx = index
        for level in self.levels[:-1]:        # all levels except the root
            if idx % 2 == 0:                   # we are the LEFT child
                sibling_idx = idx + 1 if idx + 1 < len(level) else idx
                steps.append(ProofStep(level[sibling_idx], is_right=True))
            else:                              # we are the RIGHT child
                steps.append(ProofStep(level[idx - 1], is_right=False))
            idx //= 2
        return steps


def verify_proof(leaf_data: bytes, index: int, proof: Sequence[ProofStep],
                 root: bytes) -> bool:
    """Verify an inclusion proof. Pure function — works without the tree."""
    cur = hash_leaf(leaf_data)
    idx = index
    for step in proof:
        if step.is_right:
            cur = hash_node(cur, step.sibling)
        else:
            cur = hash_node(step.sibling, cur)
        idx //= 2
    return cur == root


__all__ = [
    "MerkleTree",
    "ProofStep",
    "verify_proof",
    "hash_leaf",
    "hash_node",
]
