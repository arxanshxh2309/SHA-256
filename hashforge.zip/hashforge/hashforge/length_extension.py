"""
Length-extension attack against ``H(secret || message)``.

Setup
-----
Imagine a server hands you a message ``m`` and the tag
``t = SHA256(secret || m)`` to authenticate it. The secret is, well,
secret. Surely you can't forge a tag for a *different* message without
knowing the secret… right?

Wrong. SHA-256 is a Merkle–Damgård construction: its internal state
*after* hashing ``X`` is exactly the same state from which it would
continue if you handed it more data. So once you know
``SHA256(secret ‖ m)``, you can resume the hash from that state and
keep appending — producing ``SHA256(secret ‖ m ‖ glue ‖ extension)``
for any extension you like, even though you never learned the secret.

The only thing you need to know is the *length* of the secret (so you
can construct the right "glue" — the padding bytes SHA-256 would have
inserted between ``m`` and the start of the next block). If you don't
know it, you guess; the typical secret is short enough that brute
force over plausible lengths is trivial.

Why HMAC fixes this
-------------------
HMAC computes ``H((K ⊕ opad) ‖ H((K ⊕ ipad) ‖ m))``. The inner hash
is wrapped by an outer one whose state the attacker can never recover
from a published tag. Length extension simply doesn't apply.

Historical note
---------------
This is the "Flickr API signature" bug from 2009. Many other APIs have
shipped the same flaw. It's why every modern crypto library has HMAC
front and center, and why "just SHA-256 the key with the message"
keeps appearing on lists of mistakes.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

from .sha256 import BLOCK_SIZE, MASK32, Sha256


def _glue_padding(total_len: int) -> bytes:
    """Compute the SHA-256 padding that would be inserted *after* a message
    of length ``total_len`` bytes (the so-called "glue" the attacker
    inserts between the original message and their extension)."""
    pad_len = (56 - (total_len + 1) % 64) % 64
    return b"\x80" + b"\x00" * pad_len + (total_len * 8).to_bytes(8, "big")


def _state_from_digest(digest: bytes) -> Tuple[int, ...]:
    """Reverse-engineer the 8-word internal state from a 32-byte digest.

    SHA-256's "finalize" is just packing the 8 H-words into 32 bytes
    big-endian. We unpack them back to use as the starting state for a
    *continuation* of the hash — the move that breaks naive MACs.
    """
    if len(digest) != 32:
        raise ValueError("digest must be exactly 32 bytes")
    return tuple(
        int.from_bytes(digest[i * 4 : i * 4 + 4], "big") for i in range(8)
    )


@dataclass
class ForgedMessage:
    """The output of a successful length-extension forge.

    ``forged_message`` is what the server should be told it's verifying:
    the original message, then the SHA-256 padding bytes ("glue"), then
    the attacker's appended extension. ``forged_tag`` is the tag the
    server's check will compute over ``secret ‖ forged_message`` — so
    it matches the tag the *attacker* hands them, despite the attacker
    never knowing ``secret``.
    """
    forged_message: bytes   # original ‖ glue ‖ extension
    forged_tag: bytes       # SHA256(secret ‖ forged_message), without the secret
    glue: bytes             # the SHA-256 padding bytes that close the original msg
    extension: bytes        # attacker-chosen suffix


def forge_extension(
    original_tag: bytes,
    original_msg: bytes,
    secret_length: int,
    extension: bytes,
) -> ForgedMessage:
    """Forge ``SHA256(secret ‖ original_msg ‖ glue ‖ extension)`` from
    ``SHA256(secret ‖ original_msg)`` *without knowing* the secret.

    Parameters
    ----------
    original_tag : bytes
        The known 32-byte SHA-256 tag.
    original_msg : bytes
        The known message (everything past the secret).
    secret_length : int
        The length of the unknown secret in bytes. (Guess if needed —
        try every plausible length, e.g. 8..64, until the server accepts
        one. Each guess is cheap.)
    extension : bytes
        Whatever you want to tack onto the end of the message.

    Returns
    -------
    ForgedMessage
        Ready-to-submit attack payload.
    """
    # 1. Compute the glue: the SHA-256 padding that would have closed the
    #    block containing (secret ‖ original_msg). This becomes part of
    #    the message the server ends up verifying.
    glue = _glue_padding(secret_length + len(original_msg))

    # 2. Recover the internal state from the published tag.
    state = _state_from_digest(original_tag)

    # 3. Continue hashing as if SHA-256 had never been finalized. The
    #    "_initial_length" tells the new hasher how many bytes of message
    #    it should *pretend* it has already consumed, so that when *it*
    #    finalizes, it includes the right total length in the trailing
    #    64-bit field.
    already_hashed = secret_length + len(original_msg) + len(glue)
    h = Sha256(_initial_state=state, _initial_length=already_hashed)
    h.update(extension)
    forged_tag = h.digest()

    return ForgedMessage(
        forged_message=original_msg + glue + extension,
        forged_tag=forged_tag,
        glue=glue,
        extension=extension,
    )


__all__ = ["forge_extension", "ForgedMessage"]
