"""
SHA-256 from scratch — FIPS 180-4 §6.2.

A faithful, readable, byte-for-byte compatible implementation of the
SHA-256 hash function. Intended for *learning* and for building things
on top (HMAC, Merkle trees, length-extension demos). For production,
use ``hashlib.sha256``: it's the same algorithm written in C and runs
~50× faster.

Every variable name in this file matches the FIPS 180-4 specification
exactly (``a``..``h``, ``T1``, ``T2``, ``W``, ``K``, ``H``) so you can
read the spec with one eye and the code with the other.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional

MASK32 = 0xFFFFFFFF
BLOCK_SIZE = 64    # 512 bits
DIGEST_SIZE = 32   # 256 bits

# ---------------------------------------------------------------------------
#  §4.2.2 — Round constants K[0..63]
#  First 32 bits of the fractional parts of the cube roots of the first
#  64 primes (2..311).
# ---------------------------------------------------------------------------
K: tuple[int, ...] = (
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
)

# §5.3.3 — Initial hash value H^(0). First 32 bits of fractional parts of
# square roots of the first 8 primes (2, 3, 5, 7, 11, 13, 17, 19).
H0: tuple[int, ...] = (
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
)


# ---------------------------------------------------------------------------
#  §4.1.2 — Logical functions for SHA-256
# ---------------------------------------------------------------------------
def _rotr(x: int, n: int) -> int:
    """Right rotation of a 32-bit word."""
    return ((x >> n) | (x << (32 - n))) & MASK32


def _ch(x: int, y: int, z: int) -> int:
    """Choose: bit i of x picks bit i of y or z."""
    return (x & y) ^ (~x & MASK32 & z)


def _maj(x: int, y: int, z: int) -> int:
    """Majority: bit i of output is the majority of bits at position i."""
    return (x & y) ^ (x & z) ^ (y & z)


def _bsig0(x: int) -> int:  # capital sigma 0
    return _rotr(x, 2) ^ _rotr(x, 13) ^ _rotr(x, 22)


def _bsig1(x: int) -> int:  # capital sigma 1
    return _rotr(x, 6) ^ _rotr(x, 11) ^ _rotr(x, 25)


def _ssig0(x: int) -> int:  # lowercase sigma 0
    return _rotr(x, 7) ^ _rotr(x, 18) ^ (x >> 3)


def _ssig1(x: int) -> int:  # lowercase sigma 1
    return _rotr(x, 17) ^ _rotr(x, 19) ^ (x >> 10)


# ---------------------------------------------------------------------------
#  Trace mode — recorded snapshots for educational use
# ---------------------------------------------------------------------------
@dataclass
class RoundSnapshot:
    """State after one of the 64 compression rounds."""
    t: int                        # round number 0..63
    a: int; b: int; c: int; d: int
    e: int; f: int; g: int; h: int
    W_t: int                      # message schedule word used this round
    K_t: int                      # round constant used this round


@dataclass
class BlockTrace:
    """Per-block snapshot of state and message schedule."""
    block_index: int
    raw_block: bytes
    message_schedule: List[int] = field(default_factory=list)  # W[0..63]
    rounds: List[RoundSnapshot] = field(default_factory=list)
    H_in: tuple[int, ...] = ()    # state before this block
    H_out: tuple[int, ...] = ()   # state after this block


@dataclass
class Trace:
    """Complete trace of a SHA-256 computation."""
    blocks: List[BlockTrace] = field(default_factory=list)
    padded_input: bytes = b""
    digest: bytes = b""


# ---------------------------------------------------------------------------
#  Padding — §5.1.1
# ---------------------------------------------------------------------------
def pad_message(msg: bytes) -> bytes:
    """Pad ``msg`` to a multiple of 64 bytes per FIPS 180-4 §5.1.1.

    Layout: ``msg || 0x80 || 0x00... || length-in-bits-as-64-bit-BE``.
    """
    msg_len_bits = len(msg) * 8
    # zero-pad so that total length ≡ 56 (mod 64)
    pad_len = (56 - (len(msg) + 1) % 64) % 64
    return msg + b"\x80" + b"\x00" * pad_len + msg_len_bits.to_bytes(8, "big")


# ---------------------------------------------------------------------------
#  Compression — §6.2.2
# ---------------------------------------------------------------------------
def _compress(state: tuple[int, ...], block: bytes,
              trace: Optional[BlockTrace] = None) -> tuple[int, ...]:
    """Run one block of the SHA-256 compression function and return the
    new chaining-value state. If ``trace`` is provided, fill it in."""
    assert len(block) == BLOCK_SIZE

    # 1. Prepare message schedule W[0..63]
    W = [0] * 64
    for t in range(16):
        W[t] = int.from_bytes(block[t * 4 : t * 4 + 4], "big")
    for t in range(16, 64):
        W[t] = (_ssig1(W[t - 2]) + W[t - 7] + _ssig0(W[t - 15]) + W[t - 16]) & MASK32

    # 2. Initialize working variables a..h with the chaining value
    a, b, c, d, e, f, g, h = state

    if trace is not None:
        trace.message_schedule = list(W)

    # 3. Main loop — 64 rounds
    for t in range(64):
        T1 = (h + _bsig1(e) + _ch(e, f, g) + K[t] + W[t]) & MASK32
        T2 = (_bsig0(a) + _maj(a, b, c)) & MASK32
        h = g
        g = f
        f = e
        e = (d + T1) & MASK32
        d = c
        c = b
        b = a
        a = (T1 + T2) & MASK32

        if trace is not None:
            trace.rounds.append(RoundSnapshot(
                t=t, a=a, b=b, c=c, d=d, e=e, f=f, g=g, h=h,
                W_t=W[t], K_t=K[t]))

    # 4. Add the compressed chunk to the current chaining value
    return tuple((s + v) & MASK32 for s, v in zip(state, (a, b, c, d, e, f, g, h)))


# ---------------------------------------------------------------------------
#  Public API
# ---------------------------------------------------------------------------
class Sha256:
    """Streaming SHA-256 hasher. Mirrors the ``hashlib.sha256`` interface
    enough to be a drop-in for most uses (``update`` / ``digest`` /
    ``hexdigest``), and adds an optional ``trace`` recorder."""

    block_size: int = BLOCK_SIZE
    digest_size: int = DIGEST_SIZE
    name: str = "sha256"

    def __init__(self, data: bytes = b"", *, trace: Optional[Trace] = None,
                 _initial_state: tuple[int, ...] = H0,
                 _initial_length: int = 0) -> None:
        self._state = _initial_state
        self._buffer = b""
        # Total bytes ever consumed (used for length-extension forging)
        self._length = _initial_length
        self._trace = trace
        if data:
            self.update(data)

    # ----- streaming ------------------------------------------------------
    def update(self, data: bytes) -> "Sha256":
        self._buffer += data
        self._length += len(data)
        # Process full blocks; keep a tail in the buffer.
        while len(self._buffer) >= BLOCK_SIZE:
            block = self._buffer[:BLOCK_SIZE]
            self._buffer = self._buffer[BLOCK_SIZE:]
            self._consume_block(block)
        return self

    def _consume_block(self, block: bytes) -> None:
        bt = None
        if self._trace is not None:
            bt = BlockTrace(
                block_index=len(self._trace.blocks),
                raw_block=block,
                H_in=self._state,
            )
        self._state = _compress(self._state, block, bt)
        if bt is not None:
            bt.H_out = self._state
            self._trace.blocks.append(bt)

    # ----- finalize -------------------------------------------------------
    def digest(self) -> bytes:
        # Build the final-block tail. The 64-bit length field at the end
        # must encode the TOTAL message length in bits — across all blocks
        # already consumed *plus* the buffered remainder. This is the
        # subtle bit that separates a working SHA-256 from "almost works
        # for short inputs". (FIPS 180-4 §5.1.1)
        msg_len_bits = self._length * 8
        pad_len = (56 - (len(self._buffer) + 1) % 64) % 64
        tail = (
            self._buffer
            + b"\x80"
            + b"\x00" * pad_len
            + msg_len_bits.to_bytes(8, "big")
        )

        state = self._state
        for i in range(0, len(tail), BLOCK_SIZE):
            block = tail[i : i + BLOCK_SIZE]
            bt = None
            if self._trace is not None:
                bt = BlockTrace(
                    block_index=len(self._trace.blocks),
                    raw_block=block,
                    H_in=state,
                )
            state = _compress(state, block, bt)
            if bt is not None:
                bt.H_out = state
                self._trace.blocks.append(bt)
        out = b"".join(s.to_bytes(4, "big") for s in state)
        if self._trace is not None:
            self._trace.digest = out
        return out

    def hexdigest(self) -> str:
        return self.digest().hex()


def sha256(data: bytes, *, trace: Optional[Trace] = None) -> bytes:
    """One-shot SHA-256 of ``data``.

    >>> sha256(b'abc').hex()
    'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'
    """
    h = Sha256(data, trace=trace)
    digest = h.digest()
    if trace is not None:
        # Record the canonical padded input for inspection.
        trace.padded_input = pad_message(data)
    return digest


__all__ = [
    "Sha256",
    "sha256",
    "pad_message",
    "Trace",
    "BlockTrace",
    "RoundSnapshot",
    "K",
    "H0",
    "BLOCK_SIZE",
    "DIGEST_SIZE",
]
