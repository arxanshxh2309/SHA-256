"""Hashforge — SHA-256 from scratch, with Merkle trees, HMAC, and a
length-extension attack demo.

>>> from hashforge import sha256
>>> sha256(b'abc').hex()
'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'
"""
from .hmac import hmac_sha256, verify
from .length_extension import ForgedMessage, forge_extension
from .merkle import MerkleTree, ProofStep, verify_proof
from .sha256 import (
    BLOCK_SIZE,
    DIGEST_SIZE,
    BlockTrace,
    RoundSnapshot,
    Sha256,
    Trace,
    pad_message,
    sha256,
)

__version__ = "0.1.0"

__all__ = [
    "sha256",
    "Sha256",
    "Trace",
    "BlockTrace",
    "RoundSnapshot",
    "pad_message",
    "BLOCK_SIZE",
    "DIGEST_SIZE",
    "hmac_sha256",
    "verify",
    "MerkleTree",
    "ProofStep",
    "verify_proof",
    "forge_extension",
    "ForgedMessage",
]
